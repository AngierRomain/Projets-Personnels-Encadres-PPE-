<p>
Gestion de ligues et des clubs réalisée par : <br/>
Gestion des intervenants et des bulletins de salaire réalisée par : <br/>
Gestion des formations réalisée par :<br/>
</p>