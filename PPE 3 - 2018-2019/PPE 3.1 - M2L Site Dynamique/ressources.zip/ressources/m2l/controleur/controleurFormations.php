<?php

require_once 'vue/vueFormation.php' ;