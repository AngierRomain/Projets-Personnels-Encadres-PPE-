<div class="conteneur">
	<header>
		<?php include 'haut.php' ;?>
	</header>
	<main>
	</main>
	<footer>
		<?php include 'bas.php' ;?>
	</footer>
</div>
