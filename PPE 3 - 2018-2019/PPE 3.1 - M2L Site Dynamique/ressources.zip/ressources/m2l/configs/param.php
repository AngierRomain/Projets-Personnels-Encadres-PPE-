<?php
//Définition des variables de connexion
$user = '';
$pass = '';
$dsn = '';
?>