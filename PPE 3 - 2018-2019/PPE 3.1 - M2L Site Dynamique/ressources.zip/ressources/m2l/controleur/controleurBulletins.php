<?php

require_once 'vue/vueBulletins.php' ;