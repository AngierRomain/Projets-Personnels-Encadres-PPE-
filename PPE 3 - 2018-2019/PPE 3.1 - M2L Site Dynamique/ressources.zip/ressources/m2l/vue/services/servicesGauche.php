<nav class="sidenav">
	<h3 class="titreListe">Les services</h3>
	<ul>
		<li><a href="#internet">Accès Internet</a></li>	
		<li><a href="#wifi">Accès Wifi</a></li>
		<li><a href="#telephonie">Téléphonie</a></li>
		<li><a href="#affranchissement">Affranchissement</a></li>
		<li><a href="#impression">Impression</a></li>
		<li><a href="#ftp">Serveur FTP</a></li>
		<li><a href="#reservation">Réservation de salle</a></li>
		<li><a href="#digicode">Digicode et clé Wifi</a></li>
		<li><a href="#gestion">Gestion des configurations</a></li>
		<li><a href="#postes">Intégration des postes</a></li>
	</ul>
</nav>
