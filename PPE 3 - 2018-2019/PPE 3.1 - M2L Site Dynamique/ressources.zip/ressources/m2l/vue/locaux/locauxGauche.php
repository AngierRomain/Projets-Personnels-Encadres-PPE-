<nav class="sidenav">
	<h3 class="titreListe">Les locaux</h3>
	<ul>
		<li><a href="#locaux">Présentation des locaux</a></li>
		<li><a href="#salles">Salles misent à disposition</a></li>
		<li><a href="#equipement">Équipements informatiques</a></li>
		<li><a href="#connectique">Connectique des espaces</a></li>
	</ul>
</nav>
