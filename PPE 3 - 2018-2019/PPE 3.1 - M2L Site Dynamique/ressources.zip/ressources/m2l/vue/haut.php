<div class='bandeau'>
	<div class="logo">Maison des Ligues</div>
</div>

<nav class="menuPrincipal">
	<?php
	echo $menuPrincipal;
	?>
</nav>