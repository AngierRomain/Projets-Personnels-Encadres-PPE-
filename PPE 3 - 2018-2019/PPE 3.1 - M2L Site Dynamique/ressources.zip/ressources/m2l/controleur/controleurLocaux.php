<?php
require_once 'vue/vueLocaux.php' ;