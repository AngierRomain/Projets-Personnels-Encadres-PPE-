<div class="conteneur">
	<header>
		<?php include 'haut.php' ;?>
	</header>
	<main>
		<div class='gauche'>
			
		</div>
		<div class='droite'>
			
		</div>
	</main>
	<footer>
		<?php include 'bas.php' ;?>
	</footer>
</div>